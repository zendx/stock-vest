/*! For license information please see component-inputs.js.LICENSE.txt */
"use strict";document.addEventListener("DOMContentLoaded",(function(){checkstrength()}));