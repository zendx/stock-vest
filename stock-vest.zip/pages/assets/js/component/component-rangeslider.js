/*! For license information please see component-rangeslider.js.LICENSE.txt */
"use strict";document.addEventListener("DOMContentLoaded",(function(){range2(),range3(),range4()}));