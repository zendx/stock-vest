# stock-vest
A self-contained “investment platform” WordPress plugin.
